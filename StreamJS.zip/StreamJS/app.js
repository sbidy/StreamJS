﻿
    //get decoder ready
var ebml = require("./lib/ebml.js");

    //vars for stream handling
    //const
    var clients = [];
    var TRACK_ID = "0x1654AE6B"; 
    //Data
    var ebml_head = 0;
    //Flags
    var flag_track = 0;
    var flag_cluster = 0;

    var flag;
    var request;

    //Incomming
    //HTTP
    var streamServer = require("http").createServer(function (request, response) {
        console.log("Connected - http");

        request.on("data", function (data) {
            checkDataForIdent(data);
            if (flag_track != 1) {
               //ToDo -- concat. Data to Bufffer
            }
            else {
                broadcast(data);
            }
        });
    });
    streamServer.listen("8082");


    //Outgoing
    var httpServer = require("http").createServer(function (req, res) {

        res.writeHead(200, {
            "Content-Type": "video/webm",
            "Transfer-Encoding": "chunked",
        });

        clients.push(new Clients(res));

    });
    httpServer.listen("8084");

    console.log("in -> TCP: 8081 - HTTP: 8082 /// out <- WS: 8083 - HTTP: 8084");


    //BroadCastfuntkion
    function broadcast(data) {
        clients.forEach(function (client) {
            console.log(client.getFlag);
            if (!client.getFlag) {
                client.write(ebml_head);
                client.setFlag(1);
                client.write(data);
                console.log("Fist DATA");
            }
            else {
                client.write(data);
            }
        });
    }
    //Get Buffer lenght
    function getLength(data) {
        var count = 0;
        for (var i = 0; i < data.length ; i++) {
            if (data[i] != null)
                count++;
        }
        return count;
    }
    //Check Data
    function checkDataForIdent(data) {

        var decoder = new ebml.Decoder();

        decoder.on('Tracks:end', function (data) {
            flag_track = 1;
            console.log("End");
        });
        decoder.on('Cluster', function (data) {
            flag_cluster = 0;
            console.log("Cluster");
        });
        decoder.on('Cluster:end', function (data) {
            flag_cluster = 1;
        });
        decoder.write(data);
    }

    function stringToHex(string) {
        /// <summary>
        /// Converts a string in hex notation to integer.
        /// </summary>
        /// <param name="string">string</param>
        /// <returns type="integer">int from string</returns>
        return parseInt(string, 16);
    }

    // Constructor
    function Clients(request) {
        this.request = request;
        this.flag = 0; // default value
    }
    // class methods
    Clients.prototype.setFlag = function (flag) {
        this.flag = flag;

    };
    Clients.prototype.getFlag = function () {
        return flag;
    };
    // export the class
    module.exports = Clients;